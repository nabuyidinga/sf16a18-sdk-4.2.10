#include "bang.cpp"
