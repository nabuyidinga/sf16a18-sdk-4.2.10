#include <stdio.h>

int main()
{
  printf("example2\n");
  return 0;
}
