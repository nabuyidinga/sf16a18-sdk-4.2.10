#include <stdio.h>

void pair_p_stuff()
{
  printf("Placeholder for another strange file in subdirectory\n");
}
