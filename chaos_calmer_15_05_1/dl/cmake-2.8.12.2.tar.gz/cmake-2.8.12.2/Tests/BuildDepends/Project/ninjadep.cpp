#include <stdio.h>
#include "dir/header.h"

int main() {
  printf("HEADER_STRING: %s\n", HEADER_STRING);
}
