extern int mylibA();
extern int mylibB();
extern int mylibC();
extern int mylibD();
int main() { return mylibA() + mylibB() + mylibC() + mylibD(); }
