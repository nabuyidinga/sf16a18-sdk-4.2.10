#define STAGE_2
#include "inst.cxx"
