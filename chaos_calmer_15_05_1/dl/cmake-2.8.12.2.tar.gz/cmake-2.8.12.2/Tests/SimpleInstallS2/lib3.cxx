#include "lib3.h"

float Lib3Func()
{
  return 2.0;
}
