int TSD(const char*);
