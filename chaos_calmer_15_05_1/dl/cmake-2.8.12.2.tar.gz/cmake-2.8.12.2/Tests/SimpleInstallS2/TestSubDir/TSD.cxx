#include <stdio.h>

#include "TSD.h"

int main()
{
  int res = TSD("TEST");
  printf("Hello from TSD\n");
  return res;
}
