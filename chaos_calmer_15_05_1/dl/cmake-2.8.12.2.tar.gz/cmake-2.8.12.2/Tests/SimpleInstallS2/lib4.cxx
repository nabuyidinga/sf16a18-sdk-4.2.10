#include "lib4.h"

float Lib4Func()
{
  return 4.0;
}

