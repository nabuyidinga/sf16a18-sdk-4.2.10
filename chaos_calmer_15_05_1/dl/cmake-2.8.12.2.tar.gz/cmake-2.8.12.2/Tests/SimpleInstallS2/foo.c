char* foo = "Foo";

int SomeFunctionInFoo()
{
  return 5;
}
