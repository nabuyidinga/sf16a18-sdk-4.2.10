#include "lib1.h"

float Lib1Func()
{
  return 2.0;
}
