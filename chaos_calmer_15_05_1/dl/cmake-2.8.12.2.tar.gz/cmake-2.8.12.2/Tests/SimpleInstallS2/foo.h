#ifdef __cplusplus
extern "C" {
#endif

extern char* foo;
extern int SomeFunctionInFoo();

#ifdef __cplusplus
}
#endif

