extern float Lib1Func();
