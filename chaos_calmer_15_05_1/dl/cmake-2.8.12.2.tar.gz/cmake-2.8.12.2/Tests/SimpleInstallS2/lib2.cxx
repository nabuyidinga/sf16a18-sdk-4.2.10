#include "lib2.h"

float Lib2Func()
{
  return 1.0;
}
