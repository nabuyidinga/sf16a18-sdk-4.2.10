void OneFunc();
void TwoFunc();

int main()
{
  OneFunc();
  TwoFunc();
  return 0;
}
