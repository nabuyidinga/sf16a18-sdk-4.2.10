//
//  TotalFunction.c
//  NavApp3
//
//  Created by David Cole on 8/10/11.
//  Copyright 2011 Kitware, Inc. All rights reserved.
//

#include "TotalFunction.h"

int Total(const char *context)
{
  return 22;
}
