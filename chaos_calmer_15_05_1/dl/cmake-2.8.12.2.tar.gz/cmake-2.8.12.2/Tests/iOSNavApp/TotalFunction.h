//
//  TotalFunction.h
//  NavApp3
//
//  Created by David Cole on 8/10/11.
//  Copyright 2011 Kitware, Inc. All rights reserved.
//

#ifndef NavApp3_TotalFunction_h
#define NavApp3_TotalFunction_h

int Total(const char *context);

#endif
