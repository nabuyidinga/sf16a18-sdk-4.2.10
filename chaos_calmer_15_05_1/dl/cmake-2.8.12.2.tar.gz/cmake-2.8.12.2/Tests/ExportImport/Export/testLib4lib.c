int testLib4lib(void)
{
  return 0;
}
