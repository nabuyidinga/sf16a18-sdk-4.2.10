extern "C" int testLib6cxx(void)
{
  // Reference C++ standard library symbols.
  delete new int;
  return 0;
}
