
#ifndef TESTSHAREDLIBREQUIREDUSER2_H
#define TESTSHAREDLIBREQUIREDUSER2_H

#include "testsharedlibrequireduser2_export.h"

#include "testSharedLibRequired.h"

struct TESTSHAREDLIBREQUIREDUSER2_EXPORT TestSharedLibRequiredUser2
{
  TestSharedLibRequired foo();
};

#endif
