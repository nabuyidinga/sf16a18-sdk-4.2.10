
#ifndef RENAMED_H
#define RENAMED_H

#include "renamed_on_export_export.h"

struct RENAMED_ON_EXPORT_EXPORT Renamed
{
  int foo();
};

#endif
