
#include "renamed.h"

int Renamed::foo()
{
  return 0;
}
