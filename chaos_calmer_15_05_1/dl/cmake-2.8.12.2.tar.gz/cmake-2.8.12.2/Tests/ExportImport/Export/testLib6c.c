extern int testLib6cxx(void);
int testLib6(void)
{
  return testLib6cxx();
}
