
#ifndef TESTSHAREDLIBREQUIRED_H
#define TESTSHAREDLIBREQUIRED_H

#include "testsharedlibrequired_export.h"

struct TESTSHAREDLIBREQUIRED_EXPORT TestSharedLibRequired
{
  int foo();
};

#endif
