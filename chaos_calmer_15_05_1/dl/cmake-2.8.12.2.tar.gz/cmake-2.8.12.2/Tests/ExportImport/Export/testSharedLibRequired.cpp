
#include "testSharedLibRequired.h"

int TestSharedLibRequired::foo()
{
  return 0;
}
