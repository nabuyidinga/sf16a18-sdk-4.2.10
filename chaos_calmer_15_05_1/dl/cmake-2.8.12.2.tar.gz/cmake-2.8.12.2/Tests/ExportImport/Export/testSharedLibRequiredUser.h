
#ifndef TESTSHAREDLIBREQUIREDUSER_H
#define TESTSHAREDLIBREQUIREDUSER_H

#include "testsharedlibrequireduser_export.h"

struct TESTSHAREDLIBREQUIREDUSER_EXPORT TestSharedLibRequiredUser
{
  int foo();
};

#endif
