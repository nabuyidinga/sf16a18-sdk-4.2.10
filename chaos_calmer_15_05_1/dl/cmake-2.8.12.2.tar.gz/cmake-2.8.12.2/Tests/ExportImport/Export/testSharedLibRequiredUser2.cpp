
#include "testSharedLibRequiredUser2.h"

TestSharedLibRequired TestSharedLibRequiredUser2::foo()
{
  TestSharedLibRequired req;
  return req;
}
