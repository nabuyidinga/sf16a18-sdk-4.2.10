
extern int testLib1(void);

int testLib2(void) { return testLib1(); }
