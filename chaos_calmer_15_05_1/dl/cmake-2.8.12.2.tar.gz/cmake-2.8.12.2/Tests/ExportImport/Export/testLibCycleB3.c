int testLibCycleB3(void) { return 0; }
