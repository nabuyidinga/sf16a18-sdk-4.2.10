int testLibRequired(void) { return 0; }
