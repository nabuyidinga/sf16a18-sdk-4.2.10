
#include "cmp0022.h"

int cmp0022()
{
  return 0;
}
