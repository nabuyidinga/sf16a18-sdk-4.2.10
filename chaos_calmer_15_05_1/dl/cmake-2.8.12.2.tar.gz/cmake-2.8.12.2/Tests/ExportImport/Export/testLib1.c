int testLib1(void) { return 0; }
