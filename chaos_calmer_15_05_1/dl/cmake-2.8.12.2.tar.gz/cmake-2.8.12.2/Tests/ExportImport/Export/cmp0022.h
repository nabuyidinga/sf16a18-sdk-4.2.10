
#include "cmp0022_export.h"

int CMP0022_EXPORT cmp0022();
