
#include "subdir.h"

int SubDirObject::foo()
{
  return 0;
}
