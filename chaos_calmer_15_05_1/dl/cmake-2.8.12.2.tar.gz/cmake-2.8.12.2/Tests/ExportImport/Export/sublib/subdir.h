
#ifndef SUBDIR_H
#define SUBDIR_H

#include "subdirlib_export.h"

struct SUBDIRLIB_EXPORT SubDirObject
{
  int foo();
};

#endif
