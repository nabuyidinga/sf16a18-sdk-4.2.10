
#ifndef TESTSHAREDLIBDEPENDS_H
#define TESTSHAREDLIBDEPENDS_H

#include "testsharedlibdepends_export.h"

#include "testSharedLibRequired.h"
#include "renamed.h"

struct TESTSHAREDLIBDEPENDS_EXPORT TestSharedLibDepends
{
  int foo();
};

#endif
