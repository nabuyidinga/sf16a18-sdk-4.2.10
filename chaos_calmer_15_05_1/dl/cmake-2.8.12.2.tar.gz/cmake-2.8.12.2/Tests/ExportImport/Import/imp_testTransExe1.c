extern int imp_lib1(void);

int main()
{
  return imp_lib1();
}
