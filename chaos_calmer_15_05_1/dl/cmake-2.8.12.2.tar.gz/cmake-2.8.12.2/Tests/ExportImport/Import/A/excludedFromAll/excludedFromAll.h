
#include "excludedfromall_export.h"

int EXCLUDEDFROMALL_EXPORT excludedFromAll();
