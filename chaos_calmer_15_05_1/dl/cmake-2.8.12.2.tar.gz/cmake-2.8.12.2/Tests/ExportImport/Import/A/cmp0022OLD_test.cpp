
#ifdef USING_TESTLIB2
#error Unexpected USING_TESTLIB2
#endif
#ifndef USING_TESTLIB3
#error Expected USING_TESTLIB3
#endif

int main(void)
{
  return 0;
}
