
#include <testLib4/testLib4.h>

#ifndef TESTLIB4_H
#error Expected define TESTLIB4_H
#endif
