
#ifndef USING_TESTSHAREDLIBREQUIRED
#error Expected USING_TESTSHAREDLIBREQUIRED
#endif

#include "excludedFromAll.h"

int main(void)
{
  return excludedFromAll();
}
