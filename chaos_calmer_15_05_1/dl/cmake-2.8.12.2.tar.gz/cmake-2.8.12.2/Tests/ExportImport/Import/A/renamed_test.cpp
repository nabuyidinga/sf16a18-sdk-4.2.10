
#include "renamed.h"

int main(int, char **)
{
  Renamed ren;
  return ren.foo();
}
