#include "testLib2.h"

int imp_lib1(void)
{
  return testLib2();
}
