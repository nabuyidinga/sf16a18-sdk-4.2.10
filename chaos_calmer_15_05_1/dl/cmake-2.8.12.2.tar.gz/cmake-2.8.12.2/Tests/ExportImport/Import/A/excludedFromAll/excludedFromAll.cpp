
#include "excludedFromAll.h"

int excludedFromAll()
{
  return 0;
}
