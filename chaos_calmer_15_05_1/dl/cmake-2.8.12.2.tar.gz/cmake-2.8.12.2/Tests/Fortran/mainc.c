extern int myc(void);
int main()
{
  return myc();
}
