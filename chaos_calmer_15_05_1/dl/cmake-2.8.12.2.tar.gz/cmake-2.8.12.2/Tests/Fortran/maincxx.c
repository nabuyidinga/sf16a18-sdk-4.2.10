extern int myc(void);
extern int mycxx(void);
int main()
{
  return myc() + mycxx();
}
