#ifdef BAR
  PRINT * , 'BAR was defined via ADD_DEFINITIONS'
#else
  PRINT *, 'If you can read this something went wrong'
#endif
