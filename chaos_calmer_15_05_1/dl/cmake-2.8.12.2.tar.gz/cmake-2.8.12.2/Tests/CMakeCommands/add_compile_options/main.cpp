
#ifdef DO_GNU_TESTS
#  ifndef TEST_OPTION
#  error Expected TEST_OPTION
#  endif
#endif

int main(void)
{
  return 0;
}
