
#include "depd_export.h"

#include "depA.h"

struct DEPD_EXPORT DepD
{
  int foo();

  DepA getA();
};
