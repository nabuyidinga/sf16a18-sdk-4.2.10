
#include "depD.h"

int DepD::foo()
{
  return 0;
}

DepA DepD::getA()
{
  DepA a;
  return a;
}
