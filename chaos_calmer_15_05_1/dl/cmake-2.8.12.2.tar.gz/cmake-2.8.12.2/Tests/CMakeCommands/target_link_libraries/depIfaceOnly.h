
#include "depifaceonly_export.h"

struct DEPIFACEONLY_EXPORT DepIfaceOnly
{
  int foo();
};
