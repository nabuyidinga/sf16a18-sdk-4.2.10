
#include "depg_export.h"

struct DEPG_EXPORT DepG
{
  int foo();
};
