
#include "depG.h"

int DepG::foo()
{
  return 0;
}
