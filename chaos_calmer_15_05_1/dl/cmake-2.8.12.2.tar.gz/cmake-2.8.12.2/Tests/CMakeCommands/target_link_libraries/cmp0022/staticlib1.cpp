
int staticlib1() { return 0; }
