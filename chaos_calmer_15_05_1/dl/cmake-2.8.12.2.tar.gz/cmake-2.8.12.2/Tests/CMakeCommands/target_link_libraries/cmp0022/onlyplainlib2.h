
#include "onlyplainlib1.h"

#ifdef _WIN32
__declspec(dllexport)
#endif
OnlyPlainLib1 onlyPlainLib2();
