
#include "cmp0022ifacelib.h"

CMP0022Iface cmp0022iface()
{
  CMP0022Iface iface;
  iface.Value = 0;
  return iface;
}
