
#include "staticlib1.h"
#include "staticlib2.h"

int main()
{
  return staticlib1() + staticlib2();
}
