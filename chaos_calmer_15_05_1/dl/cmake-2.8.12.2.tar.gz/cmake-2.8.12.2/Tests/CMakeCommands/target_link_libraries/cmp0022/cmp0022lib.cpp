
#include "cmp0022lib.h"

CMP0022Iface cmp0022()
{
  return cmp0022iface();
}
