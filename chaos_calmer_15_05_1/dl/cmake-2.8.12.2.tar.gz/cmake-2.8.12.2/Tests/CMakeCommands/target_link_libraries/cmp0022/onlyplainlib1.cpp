
#include "onlyplainlib1.h"

OnlyPlainLib1::OnlyPlainLib1()
  : result(0)
{

}

int OnlyPlainLib1::GetResult()
{
  return result;
}
