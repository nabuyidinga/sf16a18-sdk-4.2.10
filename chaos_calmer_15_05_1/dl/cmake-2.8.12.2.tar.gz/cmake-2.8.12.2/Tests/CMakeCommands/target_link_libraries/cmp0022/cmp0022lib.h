
#include "cmp0022lib_export.h"

#include "cmp0022ifacelib.h"

CMP0022Iface CMP0022LIB_EXPORT cmp0022();
