
#include "onlyplainlib2.h"

OnlyPlainLib1 onlyPlainLib2()
{
  OnlyPlainLib1 opl1;
  return opl1;
}
