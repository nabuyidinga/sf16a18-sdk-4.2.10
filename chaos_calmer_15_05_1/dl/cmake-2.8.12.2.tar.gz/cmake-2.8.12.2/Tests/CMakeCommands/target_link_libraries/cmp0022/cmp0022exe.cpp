
#include "cmp0022lib.h"

int main(void)
{
  return cmp0022().Value;
}
