
int staticlib2() { return 0; }
