
#include "cmp0022ifacelib_export.h"

struct CMP0022Iface
{
  int Value;
};

CMP0022Iface CMP0022IFACELIB_EXPORT cmp0022iface();
