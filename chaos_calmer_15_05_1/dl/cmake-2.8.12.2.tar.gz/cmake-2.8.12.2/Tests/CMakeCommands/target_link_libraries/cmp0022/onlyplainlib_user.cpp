
#include "onlyplainlib2.h"

int main(int argc, char **argv)
{
  return onlyPlainLib2().GetResult();
}
