
#include "libgenex_export.h"

#ifndef LIBGENEX_H
#define LIBGENEX_H

struct LIBGENEX_EXPORT LibGenex
{
  int foo();
};

#endif
