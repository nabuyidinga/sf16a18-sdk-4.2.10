
#include "depIfaceOnly.h"

int DepIfaceOnly::foo()
{
  return 0;
}
