#include "properties.h"
#include "properties2.h"

#if defined HAVE_PROPERTIES_H && defined HAVE_PROPERTIES2_H
int main ()
{
  return 0;
}
#endif
