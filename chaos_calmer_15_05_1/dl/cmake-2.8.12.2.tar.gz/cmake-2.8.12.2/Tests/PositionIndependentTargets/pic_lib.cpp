
#include "pic_test.h"

class PIC_TEST_EXPORT Dummy
{
  int dummy();
};

int Dummy::dummy()
{
  return 0;
}
