
#include "libA.h"

LibA::LibA(QObject *parent)
  : QObject(parent)
{

}

int LibA::foo()
{
  return 0;
}
