#include <CoreServices/CoreServices.r>

resource 'STR#' (126)
{ {
    "${FBSTRING_LegalCopyright}",
    "${FBSTRING_ProductName}"
} };

resource 'STR#' (127)
{ {
    "${FBSTRING_FileDescription}"
} };

resource 'STR#' (128)
{ {
    "${FBSTRING_MIMEType}",
    "${FBSTRING_FileExtents}"
} };
