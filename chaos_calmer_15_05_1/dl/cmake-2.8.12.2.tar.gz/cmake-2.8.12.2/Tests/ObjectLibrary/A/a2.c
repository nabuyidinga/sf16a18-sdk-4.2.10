#include "a.h"
int a2(void) { return 0; }
