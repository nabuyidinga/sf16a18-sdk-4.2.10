#ifndef A_DEF
# error "A_DEF not defined"
#endif
#ifdef B_DEF
# error "B_DEF must not be defined"
#endif
