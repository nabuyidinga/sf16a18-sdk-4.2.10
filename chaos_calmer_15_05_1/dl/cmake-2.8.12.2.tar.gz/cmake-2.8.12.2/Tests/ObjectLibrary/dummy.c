int dummy(void) {return 0;}
