#include "b.h"
EXPORT_B int b1(void) { return 0; }
