int jumpStatic() { return 0; }
