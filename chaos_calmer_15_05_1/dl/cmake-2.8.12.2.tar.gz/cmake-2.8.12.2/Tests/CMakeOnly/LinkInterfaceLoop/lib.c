int lib(void) { return 0; }
