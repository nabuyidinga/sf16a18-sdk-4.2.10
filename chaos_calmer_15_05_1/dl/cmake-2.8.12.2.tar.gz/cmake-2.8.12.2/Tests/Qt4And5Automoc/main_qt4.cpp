
#include "main.cpp"

#include "main_qt4.moc"
