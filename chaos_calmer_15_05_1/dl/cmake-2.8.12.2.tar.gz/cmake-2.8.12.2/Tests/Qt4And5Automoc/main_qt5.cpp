
#include "main.cpp"

#include "main_qt5.moc"
