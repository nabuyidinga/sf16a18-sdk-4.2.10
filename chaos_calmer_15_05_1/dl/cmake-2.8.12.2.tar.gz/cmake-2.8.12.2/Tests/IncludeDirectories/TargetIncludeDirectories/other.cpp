#ifdef _WIN32
__declspec(dllexport)
#endif
int other() {
  return 0;
}
