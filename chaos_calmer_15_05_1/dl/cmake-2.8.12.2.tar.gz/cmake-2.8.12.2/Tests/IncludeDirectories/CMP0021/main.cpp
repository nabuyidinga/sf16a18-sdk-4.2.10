
#include "cmp0021.h"

#ifndef CMP0021_DEFINE
#error Expected CMP0021_DEFINE
#endif

int main(int, char **)
{
  return 0;
}
