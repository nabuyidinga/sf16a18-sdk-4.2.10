
#include "upstream.h"

int consumer()
{
  return upstream();
}
