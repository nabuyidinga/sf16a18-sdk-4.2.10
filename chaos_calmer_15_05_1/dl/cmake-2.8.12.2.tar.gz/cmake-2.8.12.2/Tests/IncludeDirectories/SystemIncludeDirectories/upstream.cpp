
#include "upstream.h"

int upstream() { return systemlib(); }
