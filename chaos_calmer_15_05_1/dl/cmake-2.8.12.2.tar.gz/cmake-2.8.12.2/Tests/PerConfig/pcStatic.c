const char* pcStatic(void)
{
  return "INFO:symbol[pcStatic]";
}
