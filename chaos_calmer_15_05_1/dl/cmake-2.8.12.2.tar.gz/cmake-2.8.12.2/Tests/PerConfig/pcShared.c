#include "pcShared.h"
const char* pcShared(void)
{
  return "INFO:symbol[pcShared]";
}
