#include "libcxx2.h"

float LibCxx2Class::Method()
{
  return 1.0;
}
