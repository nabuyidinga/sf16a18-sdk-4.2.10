class LibCxx1Class
{
public:
  static float Method();
};
